/*
SQLyog Community v13.1.6 (64 bit)
MySQL - 10.4.13-MariaDB 
*********************************************************************
*/
/*!40101 SET NAMES utf8 */;

create table `category` (
	`category_id` int (11),
	`title` varchar (150),
	`description` text ,
	`image` text ,
	`status` smallint (6),
	`created_on` datetime ,
	`created_by` int (11),
	`updated_on` datetime ,
	`updated_by` int (11)
); 
insert into `category` (`category_id`, `title`, `description`, `image`, `status`, `created_on`, `created_by`, `updated_on`, `updated_by`) values('1','test','cxzzzzzzzzzzzzzzzzzzzzzzzz','wsndsjdjsa','0','2020-08-28 22:43:02','1','2020-08-28 22:43:11','1');
insert into `category` (`category_id`, `title`, `description`, `image`, `status`, `created_on`, `created_by`, `updated_on`, `updated_by`) values('2','edfdsf','dsfffffffffffffffffffff','1598658741.jpg','0',NULL,NULL,'2020-08-29 01:52:21','4');
insert into `category` (`category_id`, `title`, `description`, `image`, `status`, `created_on`, `created_by`, `updated_on`, `updated_by`) values('3','title','this is an test category','1598658717.png','0','2020-08-28 23:31:57','4','2020-08-29 01:51:57','4');
insert into `category` (`category_id`, `title`, `description`, `image`, `status`, `created_on`, `created_by`, `updated_on`, `updated_by`) values('4','thsi si an second testing','this is an testing','','1','2020-08-28 23:32:56','4','2020-08-28 23:32:56','4');
insert into `category` (`category_id`, `title`, `description`, `image`, `status`, `created_on`, `created_by`, `updated_on`, `updated_by`) values('6','fdsfdsfsdfs123','fdsssssssssssssssssssssssss','1598658693.jpg','0','2020-08-29 01:28:34','4','2020-08-29 01:51:33','4');
