/*
SQLyog Community v13.1.6 (64 bit)
MySQL - 10.4.13-MariaDB 
*********************************************************************
*/
/*!40101 SET NAMES utf8 */;

create table `product_category` (
	`id` int (11),
	`product_id` int (11),
	`category_id` int (11)
); 
insert into `product_category` (`id`, `product_id`, `category_id`) values('4','5','1');
insert into `product_category` (`id`, `product_id`, `category_id`) values('5','6','2');
insert into `product_category` (`id`, `product_id`, `category_id`) values('6','6','3');
insert into `product_category` (`id`, `product_id`, `category_id`) values('7','6','4');
insert into `product_category` (`id`, `product_id`, `category_id`) values('12','3','1');
insert into `product_category` (`id`, `product_id`, `category_id`) values('13','1','6');
