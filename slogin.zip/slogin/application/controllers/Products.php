<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Products extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        if (!$this->session->userdata('logged_in')) {
            redirect('login');
        }
        $this->load->model('product_model');
        $this->load->helper('product_helper');
    }

    function index()
    {
        $list_data =  $this->product_model->product_list();
        $data['list'] = $list_data;
        $data['title'] = 'Product List';
        //====load view ===========
        $this->load->view('product/product_list.php',$data);
    }
    function add_product()
    {   $id ='';
        $login_id = $this->session->userdata('user_id');
        $data = array();
        $data['title'] ='Add Product';
        $data['cat_data'] = $this->product_model->all_category_list();

        if ( isset($_POST['add_cat_btn']) ) {
            $this->form_validation->set_rules('category_id[]', 'Category', 'required|trim');
            $this->form_validation->set_rules('title', 'Title', 'required|trim');
            $this->form_validation->set_rules('description', 'Description', 'trim');
            $this->form_validation->set_rules('status', 'Status', 'trim|required');
            $this->form_validation->set_rules('price', 'Price', 'trim|required');
            if (empty($_FILES['image']['name']))
            {
                $this->form_validation->set_rules('image', 'Category Image', 'required');
            }

            if($this->form_validation->run() == TRUE) {
                $mime_type = 'Image';
                if ( $_FILES["image"]["name"] <> "" ) {
                    $ext          = strtolower(end(explode(".", $_FILES["image"]["name"])));
                    $new_img_name = time() . '.' . $ext;
                    $filePath     = FILE_URL . $new_img_name;
                    $size         = $_FILES['image']['size'];
                    //for mime type Image

                    if ( $ext == 'jpeg' || $ext == 'jpg' || $ext == 'png' || $ext == 'gif' ) {
                        if ( move_uploaded_file($_FILES["image"]["tmp_name"], $filePath) ) {
                            $actualfilePath = FILE_PATH . $new_img_name;
                        }
                    }
                }
                $data = array(
                    'price' => $this->input->post('price'),
                    'title' => $this->input->post('title'),
                    'description' => $this->input->post('description'),
                    'status' => $this->input->post('status'),
                    'created_on' => date('Y-m-d H:i:s'),
                    'created_by' => $login_id,
                    'updated_on' => date('Y-m-d H:i:s'),
                    'updated_by' => $login_id,
                    'image' =>$new_img_name

                );
                $product_id = $this->product_model->save($data);
                //==========save product category=======
                if($product_id >0) {
                    $checkbox = $this->input->post('category_id');
                    for($i=0;$i<count($checkbox);$i++){
                        $category_id = $checkbox[$i];
                        $product_cat_data = array(
                            'product_id' => $product_id,
                            'category_id' => $category_id,
                        );
                        $id =$this->product_model->save_category($product_cat_data);


                    }
                    }
            }
            }
            if ( $id >0 ) {
                $this->session->set_flashdata('response_message_suceess', 'Product Created Successfully');
                redirect(base_url() . 'products');
            } else {
                //Load views
                $this->load->view('product/add_product.php',$data);
            }


        //$this->product_model->save($data);
    }
    function edit_product()
    {
        $product_id_datta = $this->uri->segment(2);
        $id ='';
        $data['title'] ='Edit Product';
        $login_id = $this->session->userdata('user_id');
        $data['cat_data'] = $this->product_model->all_category_list();

        $data['list'] = $this->product_model->product_list($product_id_datta);

        if ( isset($_POST['edit_cat_btn']) ) {
            $this->form_validation->set_rules('category_id[]', 'Category', 'required|trim');
            $this->form_validation->set_rules('title', 'Title', 'required|trim');
            $this->form_validation->set_rules('description', 'Description', 'trim');
            $this->form_validation->set_rules('status', 'Status', 'trim|required');
            $this->form_validation->set_rules('price', 'Price', 'trim|required');
            $hidden_image = $this->input->post('old_image');

            if (empty($_FILES['image']['name']) && $hidden_image ='' && $hidden_image =null)
            {
                $this->form_validation->set_rules('image', 'Product Image', 'required');
            }

            if($this->form_validation->run() == TRUE) {
                if ( $_FILES["image"]["name"] <> "" ) {
                     $ext = pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION);;
                    $new_img_name = time() . '.' . $ext;
                    $filePath     = FILE_URL . $new_img_name;
                    $size         = $_FILES['image']['size'];
                    //for mime type Image

                    if ( $ext == 'jpeg' || $ext == 'jpg' || $ext == 'png' || $ext == 'gif' ) {
                        if ( move_uploaded_file($_FILES["image"]["tmp_name"], $filePath) ) {
                            $actualfilePath = FILE_PATH . $new_img_name;
                        }
                    }
                }
                if($hidden_image !='' && $new_img_name ==''){
                    $new_img_name = $hidden_image;
                }
                $data = array(
                    'price' => $this->input->post('price'),
                    'title' => $this->input->post('title'),
                    'description' => $this->input->post('description'),
                    'status' => $this->input->post('status'),
                    //'created_on' => date('Y-m-d H:i:s'),
                    //'created_by' => $login_id,
                    'updated_on' => date('Y-m-d H:i:s'),
                    'updated_by' => $login_id,
                    'image' =>$new_img_name

                );
                $product_id = $this->product_model->save($data,$product_id_datta);
                //==========save product category=======
                if($product_id >0) {
                    $this->db->where('product_id',$product_id);
                    $this->db->delete('product_category');
                    $checkbox = $this->input->post('category_id');
                    for($i=0;$i<count($checkbox);$i++){
                        $category_id = $checkbox[$i];
                        $product_cat_data = array(
                            'product_id' => $product_id,
                            'category_id' => $category_id,
                        );
                        $id =$this->product_model->save_category($product_cat_data,$product_id_datta);
                    }
                }
            }
            if ( $id >0 ) {
                $this->session->set_flashdata('response_message_suceess', 'Product Updated Successfully');
                redirect(base_url() . 'products');
            } else {
                //Load views
                $this->load->view('product/edit_product.php',$data);
            }
        }
        else {
            //====load view ===========
            $this->load->view('product/edit_product.php',$data);
        }
    }

    function delete_product()
    {
        $id= $this->uri->segment(2);
        $this->product_model->delete($id);
        $this->session->set_flashdata('response_message_suceess', 'Product Deleted Successfully');
        redirect(base_url() . 'products');


    }




}