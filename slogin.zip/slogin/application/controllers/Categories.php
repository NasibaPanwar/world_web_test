<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Categories extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        if (!$this->session->userdata('logged_in')) {
            redirect('login');
        }
        $this->load->model('category_model');
    }

    function index()
    {
        $list_data = array();
        $data['title'] ='Category List';

        $list_data =  $this->category_model->category_list();
        $data['list'] = $list_data;
        //====load  view ===========
        $this->load->view('category/category_list.php',$data);
    }

    function add_category() {
        $data = array();

        $data['title'] = 'Add Category';
        $id = '';
        $login_id = $this->session->userdata('user_id');

        if ( isset($_POST['add_cat_btn']) ) {
            $this->form_validation->set_rules('title', 'Title', 'required|trim');
            $this->form_validation->set_rules('description', 'Description', 'trim');
            $this->form_validation->set_rules('status', 'Status', 'trim|required');
            if (empty($_FILES['image']['name']))
            {
                //$this->form_validation->set_rules('image', 'Category Image', 'required');
            }

            if($this->form_validation->run() == TRUE) {
                $mime_type = 'Image';
                if ( $_FILES["image"]["name"] <> "" ) {
                    $ext          = strtolower(end(explode(".", $_FILES["image"]["name"])));
                    $new_img_name = time() . '.' . $ext;
                    $filePath     = FILE_URL . $new_img_name;
                    $size         = $_FILES['image']['size'];
                    //for mime type Image

                        if ( $ext == 'jpeg' || $ext == 'jpg' || $ext == 'png' || $ext == 'gif' ) {
                            if ( move_uploaded_file($_FILES["image"]["tmp_name"], $filePath) ) {
                                $actualfilePath = FILE_PATH . $new_img_name;
                            }
                        }
                    }
                $data = array(
                    'title' => $this->input->post('title'),
                    'description' => $this->input->post('description'),
                    'status' => $this->input->post('status'),
                    'created_on' => date('Y-m-d H:i:s'),
                    'created_by' => $login_id,
                    'updated_on' => date('Y-m-d H:i:s'),
                    'updated_by' => $login_id,
                    'image' =>$new_img_name

                );
                $id = $this->category_model->save($data);
            }
            if ( $id >0 ) {
                $this->session->set_flashdata('response_message_suceess', 'Category Created Successfully');
                redirect(base_url() . 'categories');
            } else {
                //Load views
                $this->load->view('category/add_category.php',$data);
            }
        } else {
            //Load views
            $this->load->view('category/add_category.php',$data);
        }

    }
      function edit_category() {

          $category_id = $this->uri->segment(2);
          $data = array();
          if($category_id >0){
              //==========get category data =========

              $cat_data =  $this->category_model->category_list($category_id);
              $data['list'] = $cat_data;
          }


          $data['title'] = 'Edit Category';
          $id = '';
          $login_id = $this->session->userdata('user_id');

          if ( isset($_POST['edit_cat_btn']) ) {
              $this->form_validation->set_rules('title', 'Title', 'required|trim');
              $this->form_validation->set_rules('description', 'Description', 'trim');
              $this->form_validation->set_rules('status', 'Status', 'trim|required');

              if (empty($_FILES['image']['name']))
              {
                  //$this->form_validation->set_rules('image', 'Category Image', 'required');
              }

              if($this->form_validation->run() == TRUE) {
                  $hidden_image = $this->input->post('old_image');
                  if ( $_FILES["image"]["name"] <> "" ) {
                      $ext          = strtolower(end(explode(".", $_FILES["image"]["name"])));
                      $new_img_name = time() . '.' . $ext;
                      $filePath     = FILE_URL . $new_img_name;
                      $size         = $_FILES['image']['size'];
                      //for mime type Image

                      if ( $ext == 'jpeg' || $ext == 'jpg' || $ext == 'png' || $ext == 'gif' ) {
                          if ( move_uploaded_file($_FILES["image"]["tmp_name"], $filePath) ) {
                              $actualfilePath = FILE_PATH . $new_img_name;
                          }
                      }
                  }
                  if($hidden_image !='' && $new_img_name ==''){
                      $new_img_name = $hidden_image;
                  }
                  $data = array(
                      'title' => $this->input->post('title'),
                      'description' => $this->input->post('description'),
                      'status' => $this->input->post('status'),
                      'updated_on' => date('Y-m-d H:i:s'),
                      'updated_by' => $login_id,
                      'image' =>$new_img_name

                  );
                  $id = $this->category_model->save($data,$category_id);
              }
              if ( $id >0 ) {
                  $this->session->set_flashdata('response_message_suceess', 'Category Updated Successfully');
                  redirect(base_url() . 'categories');
              } else {
                  //Load views
                  $this->load->view('category/edit_category.php',$data);
              }
          }

          else {
              //Load views
              $this->load->view('category/edit_category.php',$data);
          }

    }
    function delete_category() {
         $id = $this->uri->segment(2);
         if($id >0) {
             $this->category_model->delete($id);
             $this->session->set_flashdata('response_message_suceess', 'Category Deleted Successfully');
             redirect(base_url() . 'categories');
         }
    }


}