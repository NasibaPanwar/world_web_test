<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        if($this->session->userdata('logged_in'))
        {
            redirect('dashboard');
        }
        $this->load->model('user_model');
    }

    function index()
    {
        $this->load->view('register');
    }

    function register()
    {
        $this->form_validation->set_rules('user_name', 'Name', 'required|trim');
        $this->form_validation->set_rules('user_email', 'Email Address', 'trim|required|trim|valid_email|is_unique[user.email]');
        $this->form_validation->set_rules('user_password', 'Password', 'trim|required|min_length[6]|max_length[15]');
        $this->form_validation->set_rules('user_c_password', 'Confirm Password', 'trim|required|min_length[6]|max_length[15]');
        $this->form_validation->set_rules('user_password', 'Password', 'required|matches[user_c_password]');
         if($this->form_validation->run() == TRUE)
        {

            $encrypted_password = md5($this->input->post('user_password'));
            $data = array(
                'name'  => $this->input->post('user_name'),
                'email'  => $this->input->post('user_email'),
                'password' => $encrypted_password,
                'created_date' => date('Y-m-d H:i:s'),
                'update_date' => date('Y-m-d H:i:s'),

            );
            $id = $this->user_model->insert($data);
            if($id > 0){
                $this->session->set_flashdata('message', 'User Register Successfully...');
                redirect('dashboard');
            }
        }
        else
        {
            //Views
            $this->load->view('register.php');
        }
    }


    function login()
    {
             //load login view
        $this->load->view('login');
    }

    function user_login(){

        $this->form_validation->set_rules('user_email', 'Email Address', 'required|trim|valid_email');
        $this->form_validation->set_rules('user_password', 'Password', 'required');
        if ($this->form_validation->run() == TRUE) {
            $result = $this->user_model->login($this->input->post('user_email'), md5($this->input->post('user_password')));
            if ($result) {
                //======set session data========

                $session_data = array(
                    'user_id' => $result->user_id,
                    'name' => $result->name,
                    'logged_in' => true
                );
                $this->session->set_userdata($session_data);
                redirect(base_url().'dashboard');
            }
            else {
                //$this->session->set_flashdata('message', 'Invalid Email OR Password');
                $this->session->set_flashdata('message', 'Email / Password Invalid');
                $data['error'] ='Email / Password Invalid';
                $this->load->view('login',$data);
            }
        }
        else{
            $this->load->view('login');
        }
    }
}

?>
