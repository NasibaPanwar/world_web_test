<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home_controller extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        if (!$this->session->userdata('logged_in')) {
            redirect('login');
        }
    }

    function index()
    {
        //====load Dashboard view ===========
        $this->load->view('home');
    }

     function logout() {
        $this->session->sess_destroy();
        redirect(base_url(),'login','refresh');
    }


}