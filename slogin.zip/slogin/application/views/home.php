
<!DOCTYPE html>
<html>
<head>
    <title>User Login </title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
</head>

<body>
<div class="container">
    <br />
    <h3 align="center">User Dahboard </h3>
    <br />
    <div class="panel panel-default">
        <div class="panel-heading">Welcome User ! <?=ucfirst($this->session->userdata('name'));?>
            <a href="<?=base_url().'categories'?>" title="Category" class="btn btn-sm btn-info">Category</a>
            <a href="<?=base_url().'products'?>" title="Product" class="btn btn-sm btn-info">Product</a>
            <a href="<?=base_url().'logout'?>" title="Category" class="btn btn-sm btn-default" style="float: right">Logout</a>
        </div>

        <div class="panel-body">

        </div>
    </div>
</div>
</body>
</html>
