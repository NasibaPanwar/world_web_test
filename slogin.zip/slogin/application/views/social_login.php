<script src="<?php echo INCLUDE_ASSETS; ?>js/jquery.js"></script><!-- Jquery -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0-beta1/jquery.js"></script>
<!-- END FACEBOOK LOGIN -->
<script>
    // This is called with the results from from FB.getLoginStatus().
    function statusChangeCallback(response) {
        console.log('statusChangeCallback');
        // console.log(response);
        // The response object is returned with a status field that lets the
        // app know the current login status of the person.
        // Full docs on the response object can be found in the documentation
        // for FB.getLoginStatus().
        if (response.status === 'connected') {
            // Logged into your app and Facebook.
            testAPI();
        } else if (response.status === 'not_authorized') {
            // The person is logged into Facebook, but not your app.
            // document.getElementById('status').innerHTML = 'Please log ' +
            // 'into this app.';
        } else {
            // The person is not logged into Facebook, so we're not sure if
            // they are logged into this app or not.
            //document.getElementById('status').innerHTML = 'Please log ' +         'into Facebook.';
        }
    }
    // This function is called when someone finishes with the Login
    // Button.  See the onlogin handler attached to it in the sample
    // code below.
    function checkLoginState() {
        FB.getLoginStatus(function(response) {
            statusChangeCallback(response);
        });
    }
    window.fbAsyncInit = function() {
        FB.init({
            appId      : '969627663142166',
            xfbml      : true,
            version    : 'v2.7'
        });

    };
    // Load the SDK asynchronously
    (function(d, s, id){
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) {return;}
        js = d.createElement(s); js.id = id;
        js.src = "//connect.facebook.net/en_US/sdk.js";
        fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));
    // Here we run a very simple test of the Graph API after login is
    // successful.  See statusChangeCallback() for when this call is made.
    function testAPI() {
        //console.log('Welcome!  Fetching your information.... ');
        FB.api('/me',{ locale: 'en_US', fields: 'name,email,locale,timezone' }, function(response) {
            //  console.log('Successful login for: ' + response.name);
            console.log(response); //this for print result in console
            var name =response.name;
            var email = '';
            email= response.email;
            var provider_key_id = response.id;
            //var phone= response.phone;
            if(email!='' && name!='')
            {
                fb_social_login(name, email, provider_key_id);
                console.log('login for: ' + name);
                $('input[name="name"]').val(name);
                $('input[name="email"]').val(email);
                //$('input[name="phone"]').val(phone);
                $(".social-btn-div").css('display','none');
                var msg_contentForPrint=msgShowDiv(2,'Email id is already existing enter Password');
                $('#create_pass').html(msg_contentForPrint);
                $("#create_pass").fadeTo(4000, 500).slideUp(500, function(){});
            }
            else
            {
                if(email==''){
                    alert("Sorry your email not found please email address add and visible in Facebook");
                }
                else if(name==''){
                    alert("Sorry your name not found please enter your name in facebook");
                }
                else if(gender==''){
                    alert("Sorry your gender not found please enter your gender in facebook");
                }
                else{
                    alert("Sorry your details not found please try again");
                }
            }

        });

        /////=======================================================================================//
        function fb_social_login(name, email, provider_key_id){
            if(email != '' && email != undefined){
                $.ajax({
                    type: "POST",
                    url: "<?php echo base_url(); ?>Home_controller/social_login_fun",
                    data: {email:email,name:name,reg_type:'FB',provider_key_id: provider_key_id},
                    dataType: "json",
                    success: function(d){
                        var re_url = d.redirect_url;
                        var baseurl = '<?php echo base_url(); ?>'+re_url;
                        //console.log(baseurl);
                        window.location.href = baseurl;
                    },
                    error: function(d){
                        // alert("hello error");
                    }
                });
            }
            else{
                alert("Unable to fetch your details.");
            }
        }
        function msgShowDiv(msg_type,msgContent)
        {
            var msg_typeClass='';
            var msgTypeheadingContent='';
            if(msg_type==0)
            {
                msg_typeClass='alert-warning';
                msgTypeheadingContent='Warning';
            }
            else if(msg_type==1){
                msg_typeClass='alert-success';
                msgTypeheadingContent='Success';
            }
            else{
                msg_typeClass='alert-info';
                msgTypeheadingContent='Message ';
            }
            var contentDiv='';
            contentDiv+='<div class="alert '+msg_typeClass+' alert-" role="alert" style=" padding: 5px 35px 5px 15px ; font-size: 12px;">';
            contentDiv+='<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>';
            contentDiv+='<strong>'+msgTypeheadingContent+'!</strong> '+msgContent;
            contentDiv+='</div>';
            return contentDiv;
        }
        /////=======================================================================================//
    }
    function fb_login(){
        //alert("1");
        FB.login(function(response) {
            if (response.authResponse) {
                testAPI();

            } else {
                //user hit cancel button
                console.log('User cancelled login or did not fully authorize.');

            }
        }, {
            scope: 'user_about_me,public_profile,user_location,email'
        });
    }
</script>
<!-- END FACEBOOK LOGIN -->

<!-- GOOGLE LOGIN -->
<script type="text/javascript">

    function logout()
    {
        gapi.auth.signOut();
        location.reload();
    }
    function google_login()
    {
        var myParams = {
            'clientid' : '156761367668-sd8s4vr5p9aq6gg525cse3j6q7998do8.apps.googleusercontent.com',
            'cookiepolicy' : 'single_host_origin',
            'callback' : 'loginCallback',
            'approvalprompt':'force',
            'scope' : 'https://www.googleapis.com/auth/plus.login https://www.googleapis.com/auth/plus.profile.emails.read'
        };
        gapi.auth.signIn(myParams);
    }

    function loginCallback(result)
    {
        if(result['status']['signed_in'])
        {
            var request = gapi.client.plus.people.get(
                {
                    'userId': 'me'
                });
            request.execute(function (resp)
            {
                var email = '';
                if(resp['emails'])
                {
                    for(i = 0; i < resp['emails'].length; i++)
                    {
                        if(resp['emails'][i]['type'] == 'account')
                        {
                            email = resp['emails'][i]['value'];
                        }
                    }
                }
                //console.log(resp);
                var name = resp['displayName'];
                var key_id = resp['id'];
                var email =  email ;

                if(email!='' && name!='')
                {
                    google_social_login(name, email, key_id);
                    console.log('login for: ' + name);
                    $('input[name="name"]').val(name);
                    $('input[name="email"]').val(email);
                    $(".social-btn-div").css('display','none');
                    var msg_contentForPrint=msgShowDiv1(2,'Email id is already existing enter Password');
                    $('#create_pass').html(msg_contentForPrint);
                    $("#create_pass").fadeTo(4000, 500).slideUp(500, function(){});
                }
                else
                {
                    if(email==''){
                        alert("Sorry your email not found please email address add and visible in Google +");
                    }
                    else if(name==''){
                        alert("Sorry your name not found please enter your name in Google +");
                    }
                    else if(gender==''){
                        alert("Sorry your gender not found please enter your gender in Google +");
                    }
                    else{
                        alert("Sorry your details not found please try again");
                    }
                }
            });
        }
    }
    function google_social_login(name, email, key_id)
    {
        if(email != '' && email != undefined){
            $.ajax({
                type: "POST",
                url: "<?php echo base_url(); ?>Home_controller/social_login_fun",
                data: {email:email,name:name,provider_key_id:key_id,reg_type:'GM'},
                dataType: "json",
                success: function(d){
                    var re_url = d.redirect_url;
                    var baseurl = '<?php echo base_url(); ?>'+re_url;
                    //console.log(baseurl);
                    window.location.href = baseurl;
                },
                error: function(d){
                    //alert("hello error");
                }
            });
        }
        else{
            alert("Unable to fetch your details.");
        }
        function msgShowDiv1(msg_type,msgContent)
        {
            var msg_typeClass='';
            var msgTypeheadingContent='';
            if(msg_type==0)
            {
                msg_typeClass='alert-warning';
                msgTypeheadingContent='Warning';
            }
            else if(msg_type==1){
                msg_typeClass='alert-success';
                msgTypeheadingContent='Success';
            }
            else{
                msg_typeClass='alert-info';
                msgTypeheadingContent='Message ';
            }
            var contentDiv='';
            contentDiv+='<div class="alert '+msg_typeClass+' alert-" role="alert" style=" padding: 5px 35px 5px 15px ; font-size: 12px;">';
            contentDiv+='<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>';
            contentDiv+='<strong>'+msgTypeheadingContent+'!</strong> '+msgContent;
            contentDiv+='</div>';
            return contentDiv;
        }
    }
    function onLoadCallback()
    {
        //3P3NSqI8wnthQEXU625zwr1y
        gapi.client.setApiKey('AIzaSyD91ydwnNA2oI8sHKC4KMWSHHAj5sbQGzs');
        gapi.client.load('plus', 'v1',function(){});
    }

</script>

<script type="text/javascript">
    (function() {
        var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
        po.src = 'https://apis.google.com/js/client.js?onload=onLoadCallback';
        var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
    })();
</script>
<!-- END GOOGLE LOGIN -->

<!-- LINKEDIN LOGIN -->
<script type="text/javascript" src="//platform.linkedin.com/in.js">
    api_key:75d1lupjkepylj
    authorize: false
    //onLoad: OnLinkedInFrameworkLoad

</script>
<script type="text/javascript">
    // Setup an event listener to make an API call once auth is complete
    function OnLinkedInFrameworkLoad() {
        //alert('dfsdfs');
        IN.User.authorize(OnLinkedInAuth);
    }
    function OnLinkedInAuth() {
        linkdintestAPI();
    }
    function linkdintestAPI() {
        IN.API.Profile("me").fields("firstName", "lastName", "industry", "current-share", "location:(name)", "picture-url", "headline", "summary", "num-connections", "public-profile-url", "distance", "positions","specialties", "email-address", "languages","educations", "date-of-birth").result(function (data){
            //console.log('Welcome!  Fetching your information.... ');
            console.log(data);
            //return false;
            var member = data.values[0];
            var id=member.id;
            var firstName=member.firstName;
            var lastName=member.lastName;
            var email=member.emailAddress;
            //use information captured above
            linkedin_social_login(firstName,lastName,email);
        }).error(function (data) {
            console.log(data);
        });
        /////=============================================//====================================================//==========================================//
        function linkedin_social_login(firstName,lastName,email){
            if(email != '' && email != undefined){
                $.ajax({
                    type: "POST",
                    url: "<?php echo base_url(); ?>Home_controller/social_login_fun",
                    data: {firstName:firstName,lastName:lastName,email:email,reg_type:'LD'},
                    dataType: "json",
                    success: function(d){
                        var re_url = d.redirect_url;
                        var baseurl = '<?php echo base_url(); ?>'+re_url;
                        //console.log(baseurl);
                        window.location.href = baseurl;
                    },
                    error: function(d){
                        // alert("hello error");
                    }
                });
            }
            else{
                alert("Unable to fetch your details.");
            }
        }

    }
    /////=============================================//====================================================//==========================================//
</script>
<!-- END LINKEDIN LOGIN -->

