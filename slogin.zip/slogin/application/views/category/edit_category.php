
<!DOCTYPE html>
<html>
<head>
    <title><?=$title;?></title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
  </head>

<body>
<div class="container">
    <br />
    <h3 align="center">Edit Category </h3>
    <br />
    <div class="panel panel-default">
        <div class="panel-heading">Welcome User ! <?=ucfirst($this->session->userdata('name'));?>
            <a href="<?=base_url().'categories'?>" title="Category" class="btn btn-sm btn-info">Category</a>
            <a href="<?=base_url().'products'?>" title="Product" class="btn btn-sm btn-info">Product</a>
            <a href="<?=base_url().'logout'?>" title="Category" class="btn btn-sm btn-default" style="float: right">Logout</a>
        </div>


        <div class="panel-body">
            <form method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <label> Title*</label>
                    <input type="text" name="title" class="form-control" value="<?php echo $list->title; ?>" />
                    <span class="text-danger"><?php echo form_error('title'); ?></span>
                </div>
                <div class="form-group">
                    <label> Description
                        <textarea type="text" name="description" class="form-control" style="width: 300%"><?php echo $list->description; ?></textarea>
                        <span class="text-danger"><?php echo form_error('description'); ?></span>
                </div>
                <div class="form-group">
                    <label> Image</label>
                    <input type="file" name="image" class="form-control" />
                    <input type="hidden" value="<?=$list->image;?>" name="old_image">
                    <span class="text-danger"><?php echo form_error('image'); ?></span>
                    <?php
                    $new_img_name = $list->image;
                    $actualfilePath = FILE_PATH . $new_img_name;

                    ?>
                    <td><img src="<?=$actualfilePath;?>" style="width: 80px; height: 50px;" alt="Category Image"/></td>
                </div>
                <div class="form-group">
                    <label> Status*</label>
                    <input id="status" name="status" type="radio" class=""  value="0" <?php if($list->status==0) echo  "checked"; ?> />
                    <label for="status" class="">Inactive</label>

                    <input id="status" name="status" type="radio" class=""  value="1" <?php if($list->status==1) echo "checked"; ?> />
                    <label for="status" class="">Active</label>

                    <span class="text-danger"><?php echo form_error('status'); ?></span>
                </div>
                <div class="form-group">
                    <input type="submit" name="edit_cat_btn" value="Edit" class="btn btn-info" />&nbsp;&nbsp;
                    <a href="<?=base_url().'categories';?>" class="btn btn-default">Cancel</a>


                </div>
            </form>
        </div>
    </div>
</div>
</body>
</html>
