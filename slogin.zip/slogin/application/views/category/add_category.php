
<!DOCTYPE html>
<html>
<head>
    <title><?=$title;?> </title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
   </head>

<body>
<div class="container">
    <br />
    <h3 align="center">Add Category </h3>
    <br />
    <div class="panel panel-default">
        <div class="panel-heading">Welcome User ! <?=ucfirst($this->session->userdata('name'));?>
            <a href="<?=base_url().'categories'?>" title="Category" class="btn btn-sm btn-info">Category</a>
            <a href="<?=base_url().'products'?>" title="Product" class="btn btn-sm btn-info">Product</a>
            <a href="<?=base_url().'logout'?>" title="Category" class="btn btn-sm btn-default" style="float: right">Logout</a>
        </div>

        <div class="panel-body">
            <form method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <label> Title*</label>
                    <input type="text" name="title" class="form-control" value="<?php echo set_value('title'); ?>" />
                    <span class="text-danger"><?php echo form_error('title'); ?></span>
                </div>
                <div class="form-group">
                    <label> Description
                        <textarea type="text" name="description" class="form-control" style="width: 300%"><?=set_value('description')?></textarea>
                        <span class="text-danger"><?php echo form_error('description'); ?></span>
                </div>
                <div class="form-group">
                    <label> Image</label>
                    <input type="file" name="image" class="form-control" />
                    <span class="text-danger"><?php echo form_error('image'); ?></span>
                </div>
                <div class="form-group">
                    <label> Status*</label>
                    <input id="status" name="status" type="radio" class=""  value="0" <?php echo set_radio('status', 0); ?> />
                    <label for="status" class="">Inactive</label>

                    <input id="status" name="status" type="radio" class=""  value="1" <?php echo set_radio('status', 1); ?> />
                    <label for="status" class="">Active</label>

                    <span class="text-danger"><?php echo form_error('status'); ?></span>
                </div>
                <div class="form-group">
                    <input type="submit" name="add_cat_btn" value="Add" class="btn btn-info" />&nbsp;&nbsp;
                    <a href="<?=base_url().'categories';?>" class="btn btn-default">Cancel</a>

                </div>
            </form>
        </div>
    </div>
</div>
</body>
</html>
