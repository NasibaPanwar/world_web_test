
<!DOCTYPE html>
<html>
<head>
    <title><?=$title;?> </title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
    <script src="<?=INCLUDE_ASSETS;?>global/plugins/jquery.min.js" type="text/javascript"></script>

    <!-- DATATABLES CSS -->
    <link rel="stylesheet" href="<?=INCLUDE_ASSETS;?>global/plugins/datatables/datatables.min.css" type="text/css">
    <link rel="stylesheet"
          href="<?=INCLUDE_ASSETS;?>global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.css"
          rel="stylesheet" type="text/css"/>
        <!-- END -->


</head>

<body>
<div class="container">
    <br />
    <h3 align="center"> Category List</h3>
    <br />
    <div class="panel panel-default">
        <div class="panel-heading">Welcome User ! <?=ucfirst($this->session->userdata('name'));?>
            <a href="<?=base_url().'categories'?>" title="Categories" class="btn btn-sm btn-info">Categories</a>
            <a href="<?=base_url().'products'?>" title="Products" class="btn btn-sm btn-info">Products</a>
            <a href="<?=base_url().'logout'?>" title="Logout" class="btn btn-sm btn-default" style="float: right">Logout</a>
        </div>
        <?php if ( $this->session->flashdata('response_message_suceess') ) { ?>
            <div class="alert alert-success" style="margin-top: 10px;">
                <button class="close" data-close="alert"></button>
                <span>
                            <?php echo $this->session->flashdata('response_message_suceess'); ?>
                            </span>
            </div>
        <?php } ?>
        <div class="panel-body">
            <a href="<?=base_url().'add-category'?>" title="Add Category" class="btn btn-sm btn-success"
               style="margin-bottom: 10px"> Add Category</a>
            <hr>
        </div>

        <table id="example" datatable="" class="display" width="100%" cellspacing="0">
            <thead>
            <tr>
                <th>SNo</th>
                <th>Title</th>
                <th>Description</th>
                <th>Status</th>
                <th>Image</th>
                <th>Action</th>
            </tr>
            </thead>
            <tbody>
            <?php
            if ( $list ) {
                $i = 1;
                foreach ( $list as $lt ) {
                    $status = '';
                    $new_img_name ='';
                    $actualfilePath ='';
                    $new_img_name = $lt->image;
                    $actualfilePath = FILE_PATH . $new_img_name;
                    if($lt->status==0){
                        $status = 'Inactive';
                    }
                    else{
                        $status = 'Active';
                    }
                    ?>
                    <tr>
                        <td><?=$i;?></td>
                        <td><?=$lt->title;?></td>
                        <td><?=$lt->description;?></td>
                        <td><?=$status;?></td>
                        <td><img src="<?=$actualfilePath;?>" style="width: 80px; height: 50px;" alt="Category Image"/></td>
                        <td>
                            <a href="<?=base_url() . 'edit-category/' . $lt->category_id;?>"
                               title="Edit" class="btn btn-xs btn-success edit"
                               onclick="return confirm('Do you want to Update this record')">
                                Edit
                            </a>
                            <a href="<?=base_url() . 'delete-category/' . $lt->category_id;?>"
                               title="Delete" class="btn btn-xs btn-danger"
                               onclick="return confirm('Do you want to Delete this record')">
                                Delete
                            </a>
                        </td>

                    </tr>
                    <?php
                    $i++;
                }
            }
            ?>



            </tbody>

        </table>

    </div>


    </div>




<!-- DATATABLE PLUGINS -->
<script src="<?=INCLUDE_ASSETS;?>global/plugins/datatables/datatables.min.js" type="text/javascript"></script>
<script src="<?=INCLUDE_ASSETS;?>global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js"
        type="text/javascript"></script>
<!-- END DATATABLE PLUGINS -->

<script>
    $(document).ready(function () {
        $('#category_list').DataTable({
            scrollX: true,
            //ordering: false,
            paging: true,
        });
        $('#example').DataTable({
            scrollX: true,
            //ordering: false,
            paging: true,
        });

    })
    ;
</script>




</body>
</html>
