<html>
<head>
    <title>Social Login</title>
    <link href="<?php echo INCLUDE_ASSETS; ?>css/bootstrap.min.css" rel="stylesheet" media="screen">
    <!-- font awesome -->
    <link href="<?php echo INCLUDE_ASSETS; ?>css/font-awesome.min.css" rel="stylesheet" type="text/css" media="all"  />
    <!-- jquery -->
    <script src="<?php echo INCLUDE_ASSETS; ?>js/jquery.min.js"></script><!-- Jquery -->
    <script src="<?php echo INCLUDE_ASSETS; ?>js/bootstrap.min.js"></script><!-- bootstrap -->
</head>
<body>
    <div class="container">
        <div class="row ">
            <div class="content-wrapper">
                <div class="row" style="margin-top: 30px;">
                    <a onclick="fb_login()"; class="btn btn-success"><span class="fa fa-facebook"> Login With Facebook</span></a>
                    <a onclick="google_login()" class="btn btn-success"><span class="fa fa-google"> Login With Google</span></a>
                    <a href="<?php echo base_url(); ?>login" class="btn btn-success"><span class="fa fa-twitter"> Login With Twitter</span></a>
                    <a onclick="OnLinkedInFrameworkLoad();" class="btn btn-success"><span class="fa fa-linkedin"> Login With Linkedin</span></a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>