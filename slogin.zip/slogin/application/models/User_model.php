<?php
class User_model extends CI_Model
{
    function insert($data)
    {
        $this->db->insert('user', $data);
        return $this->db->insert_id();
    }

    function login($email, $password)
    {
        $this->db->where('email', $email);
        $this->db->where('password', $password);
        $query = $this->db->get('user');
        if($query->num_rows() == 1)
        {
            // If there is a user, then create session data
            return $query->row();
        }
      }
}

?>

