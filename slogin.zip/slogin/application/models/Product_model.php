<?php
class Product_model extends CI_Model
{
    function product_list($id =null)
    {
        $this->db->select('*');
        if($id >0){
            $this->db->where('product_id',$id);
            $query = $this->db->get('product')->row();
        }
        else{
            $query = $this->db->get('product')->result();
        }
        return $query;
    }
    function all_category_list()
    {
        $this->db->select('category_id,title');
        $query = $this->db->get('category')->result();
        return $query;
    }

     function save($data, $id =null)
    {
        if($id>0){
            $this->db->where('product_id',$id);
            $this->db->update('product',$data);
        }
        else{
            $this->db->insert('product', $data);
            $id = $this->db->insert_id();
        }
        return $id;

    }
    function save_category($data, $id =null)
    {
        if($id>0){
            //$this->db->where('product_id',$id);
            //$status =  $this->db->delete('product_category');

            $this->db->insert('product_category', $data);
            $id = $this->db->insert_id();
        }

        return $id;

    }

    function delete($id = null)
    {
        $this->db->where('product_id',$id);
        $status =  $this->db->delete('product');
       return $status;
    }
}

?>

