<?php
class Category_model extends CI_Model
{
    function category_list($id =null)
    {
        $this->db->select('*');
        if($id >0){
            $this->db->where('category_id',$id);
            $query = $this->db->get('category')->row();
        }
        else{
            $query = $this->db->get('category')->result();
        }
        return $query;




    }
    function save($data, $id =null)
    {
        if($id>0){
            $this->db->where('category_id',$id);
            $this->db->update('category',$data);
        }
        else{
            $this->db->insert('category', $data);
            $id = $this->db->insert_id();
        }
        return $id;

    }

    function delete($id = null)
    {
        $this->db->where('category_id',$id);
         $status =  $this->db->delete('category');
        return $status;
    }
}

?>

