<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class General_model extends CI_Model
{

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 *        http://example.com/index.php/welcome
	 *    - or -
	 *        http://example.com/index.php/welcome/index
	 *    - or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct()
	{
		parent::__construct();
	}
	//======Simple Insert Data in Database========//
	function insertDetails($table_name, $insert_details)
	{
		$return_value = $this->db->insert($table_name, $insert_details);
		return $return_value;
	}
	//=====Insert Data in database and return insert id=======//
	function insertDetailsWithLastInsertID($table_name, $insert_details)
	{
		$return_value = $this->db->insert($table_name, $insert_details);
		$last_insert_id = $this->db->insert_id();
		return $last_insert_id;
	}
	//======Simple Insert Batch in Database========//
	function insertDetailsUsingBatch($table_name, $insert_details)
	{
		$return_value = $this->db->insert_batch($table_name, $insert_details);
		return $return_value;
	}
	//========Update Data in Database===================//
	function updateDetails($table_name, $update_data, $where_condition, $orwhere_condition)
	{
		//===check where condition===//
		if ($where_condition != '') {
			$this->db->where($where_condition);
		}
		//=====check orwhere condition=//
		if ($orwhere_condition != '') {
			$this->db->or_where($orwhere_condition);
		}
		//=====update query=====//
		$return_data = $this->db->update($table_name, $update_data);
		return $return_data;
	}
	//=====Delete data===========//
	function deleteDetailFromDatabase($table_name, $where_condition)
	{
		$return_details = $this->db->delete($table_name, $where_condition);
		return $return_details;
	}
	//======Get View Full Detail For Details Page=================//
	function getFullDescription($table_name, $select_filds, $where_condition)
	{
		if ($select_filds != '') {
			$this->db->select($select_filds);
		} else {
			$this->db->select('*');
		}
		$this->db->from($table_name);
		$this->db->where($where_condition);
		//echo $this->db->last_query(); exit;
		$query = $this->db->get();
		$result = $query->row();
		return $result;
	}
	//====simple listing function============================//
	function listingDetails($table_name, $select_filds, $where_condition)
	{
		if ($select_filds != '') {
			$this->db->select($select_filds);
		} else {
			$this->db->select('*');
		}
		if ($where_condition != '') {
			$this->db->where($where_condition);
		}
		$query = $this->db->get($table_name);
		$result = $query->result();
		//echo $this->db->last_query(); die();
		return $result;
	}
	//listing function with order and limit
	function listingDetailswithLimitandOrderBy($table_name, $select_filds, $where_condition,$order_field,$type,$limit)
	{
		if ($select_filds != '') {
			$this->db->select($select_filds);
		} else {
			$this->db->select('*');
		}
		if ($where_condition != '') {
			$this->db->where($where_condition);
		}
		$this->db->order_by($order_field,$type);
		$this->db->limit($limit);
		$query = $this->db->get($table_name);
		$result = $query->result();
		//echo $this->db->last_query(); die();
		return $result;
	}
	//===========get table single Fild Detail====================//
	function getSingleFildDetails($table_name, $fild_name, $where_condition)
	{
		$this->db->select($fild_name);
		$this->db->from($table_name);
		$this->db->where($where_condition);
		$query = $this->db->get();
		//echo $this->db->last_query();
		$result = $query->row();
		return $result;
	}
	//===============check details exits yes or not============//
	function checkDetailsExitsYesorNot($table_name, $select_fild, $where_condition)
	{
		$this->db->select($select_fild);
		$this->db->from($table_name);
		if ($where_condition != '') {
			$this->db->where($where_condition);
		}
		$query = $this->db->get();
		$count_rows = $query->num_rows();
		return $count_rows;
	}
	//================get count record using by where condition=======/
	function getCountRecord($table_name, $where_condition)
	{
		if ($where_condition != '')
		{$this->db->where($where_condition); }
		$this->db->from($table_name);
		$total_result = $this->db->count_all_results();
		//echo $this->db->last_query();
		return $total_result;
	}
	//================get last entry details========================//
	function getLastRowDetails($table_name,$selet_fild,$where_con)
	{
		if($selet_fild!=''){
			$this->db->select($selet_fild);}
		else{
			$this->db->select('*');}
		$this->db->from($table_name);
		if($where_con!=''){
			$this->db->where($where_con);}
		$this->db->order_by("participate_id", "desc");
		$this->db->limit(1);
		$query=$this->db->get();
		$return_data=$query->row();
		return $return_data;
	}
	//================get last entry details========================//
	function getLastRowDetailsNEW($table_name,$selet_fild,$where_con,$order_by)
	{
		if($selet_fild!=''){
			$this->db->select($selet_fild);}
		else{
			$this->db->select('*');}
		$this->db->from($table_name);
		if($where_con!=''){
			$this->db->where($where_con);}
		$this->db->order_by($order_by,'DESC');
		$this->db->limit(1);
		$query=$this->db->get();
		$return_data=$query->row();
		return $return_data;
	}
	//==================this function use for all dropdown=================//
	function getOrderByListingData($table_name,$select_fild,$order_by,$where_condition)
	{
		$this->db->select($select_fild);
		$this->db->from($table_name);
		if($where_condition!=''){
			$this->db->where($where_condition);}
		$this->db->order_by($order_by);
		$query = $this->db->get();
		$result = $query->result();
		return $result;
	}
	//==================this function using GroupBy and order by details=================//
	function getGroupByAndOrderByListingData($table_name,$select_fild,$order_by,$group_by,$where_condition)
	{
		$this->db->select($select_fild);
		if($group_by!=''){
			$this->db->group_by($group_by);}
		if($where_condition!=''){
			$this->db->where($where_condition);}
		if($order_by!=''){
			$this->db->order_by($order_by);}
		$this->db->from($table_name);
		$query = $this->db->get();
		//echo $this->db->last_query();
		$result = $query->result();
		return $result;
	}
	//===================this function sum records=====================//
	function getSumRecord($table_name,$fild_value,$where_condtion)
	{
		if($fild_value!=''){
			$this->db->select_sum($fild_value);}
		else{
			$this->db->select_sum('*');}
		if($where_condtion){
			$this->db->where($where_condtion);}
		$this->db->from($table_name);
		$query_data=$this->db->get();
		return $query_data->row();
	}
	//==================this function using GroupBy and order by details=================//
	function getGroupByAndOrderByLimitListingData($table_name,$select_fild,$order_by,$group_by,$limit,$where_condition)
	{
		if($select_fild!=''){
			$this->db->select($select_fild);}
		else{
			$this->db->select('*');
		}
		if($group_by!=''){
			$this->db->group_by($group_by);}
		if($where_condition!=''){
			$this->db->where($where_condition);}
		if($order_by!=''){
			$this->db->order_by($order_by);}
		if($limit!=''){
			$this->db->limit($limit);}
		$this->db->from($table_name);
		$query = $this->db->get();
		//echo $this->db->last_query();
		$result = $query->result();
		return $result;
	}
	//==================this function using GroupBy and order by details=================//
	function getListingDataOrderAndLike($table_name,$select_fild,$order_by,$where_condition,$like_condition)
	{
		$this->db->select($select_fild);
		if($where_condition!=''){
			$this->db->where($where_condition);}
		if($order_by!=''){
			$this->db->order_by($order_by);}
		if($like_condition!=''){
			$this->db->like($like_condition);}

		$this->db->from($table_name);
		$query = $this->db->get();
		//echo $this->db->last_query();
		$result = $query->result();
		return $result;
	}
	//===========get table single Fild Detail using by order by limit====================//
	function getSingleFildDetailsUsingOrderLimit($table_name, $fild_name, $where_condition,$order_by,$limit)
	{
		$this->db->select($fild_name);
		$this->db->from($table_name);
		if($where_condition!=''){
			$this->db->where($where_condition);}
		if($order_by!=''){
			$this->db->order_by($order_by);}
		if($limit!=''){
			$this->db->limit($limit);}
		$query = $this->db->get();
		$result = $query->row();
		return $result;
	}
       
	//============================== this function for data between two date =======================//
	function GetdatabetweenTwoDate($table_name,$where_condition,$start_date,$end_date)
	{
		$this->db->select('*');
		$this->db->from($table_name);
		$this->db->where($where_condition);
		$this->db->where('login_time >=', $start_date);
		$this->db->where('login_time <=', $end_date);
		$result = $this->db->get();
		$result2 = $result->result();
		return $result2;
	}
}

