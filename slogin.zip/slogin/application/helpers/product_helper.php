<?php

/**
 * this function for total users
 * @return int return no of user
 */
function productcategory($product_id)
{
    $ci = &get_instance();
    $ci->db->select('category.title,category.category_id')
        ->from('category')
        ->join('product_category', 'category.category_id = product_category.category_id')
        ->where('product_id',$product_id);
    $query = $ci->db->get();
    $result = $query->result();
    return $result;
}


