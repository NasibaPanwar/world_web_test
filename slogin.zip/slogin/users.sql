/*
SQLyog Community v13.1.6 (64 bit)
MySQL - 10.4.13-MariaDB 
*********************************************************************
*/
/*!40101 SET NAMES utf8 */;

create table `user` (
	`user_id` int (11),
	`name` varchar (150),
	`password` varchar (765),
	`email` varchar (765),
	`created_date` datetime ,
	`update_date` datetime 
); 
insert into `user` (`user_id`, `name`, `password`, `email`, `created_date`, `update_date`) values('1','','','Coretesting Bikaner','2016-10-26 13:29:18',NULL);
insert into `user` (`user_id`, `name`, `password`, `email`, `created_date`, `update_date`) values('2','','','core','2016-10-26 13:32:25',NULL);
insert into `user` (`user_id`, `name`, `password`, `email`, `created_date`, `update_date`) values('3','nasiba','0e54e975bd4250e7465865232bdb08fc','nasiba@gmail.com',NULL,NULL);
insert into `user` (`user_id`, `name`, `password`, `email`, `created_date`, `update_date`) values('4','nasiba','e10adc3949ba59abbe56e057f20f883e','one@gmail.com','2020-08-27 22:29:54','2020-08-27 22:29:54');
