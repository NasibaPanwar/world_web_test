/*
SQLyog Community v13.1.6 (64 bit)
MySQL - 10.4.13-MariaDB 
*********************************************************************
*/
/*!40101 SET NAMES utf8 */;

create table `product` (
	`product_id` int (11),
	`title` varchar (150),
	`description` text ,
	`image` text ,
	`status` tinyint (4),
	`price` varchar (750),
	`created_on` datetime ,
	`created_by` int (11),
	`updated_on` datetime ,
	`updated_by` int (11)
); 
insert into `product` (`product_id`, `title`, `description`, `image`, `status`, `price`, `created_on`, `created_by`, `updated_on`, `updated_by`) values('1','testing','adbam,bd,mabd,msabd,m','1598667644.png','1','56.80','2020-08-29 05:47:01',NULL,'2020-08-29 04:20:44','4');
insert into `product` (`product_id`, `title`, `description`, `image`, `status`, `price`, `created_on`, `created_by`, `updated_on`, `updated_by`) values('2','thsi si an second testing','snasmn,msansa,mnamna,mnas,m','1598664334.jpg','1','750','2020-08-29 03:25:34','4','2020-08-29 03:25:34','4');
insert into `product` (`product_id`, `title`, `description`, `image`, `status`, `price`, `created_on`, `created_by`, `updated_on`, `updated_by`) values('4','thsi si an second testing','snasmn,msansa,mnamna,mnas,m','1598664561.jpg','1','750','2020-08-29 03:29:21','4','2020-08-29 03:29:21','4');
insert into `product` (`product_id`, `title`, `description`, `image`, `status`, `price`, `created_on`, `created_by`, `updated_on`, `updated_by`) values('5','thsi si an second testing','snasmn,msansa,mnamna,mnas,m','1598664580.jpg','1','750','2020-08-29 03:29:40','4','2020-08-29 03:29:40','4');
insert into `product` (`product_id`, `title`, `description`, `image`, `status`, `price`, `created_on`, `created_by`, `updated_on`, `updated_by`) values('6','onedzX m','sdmnnnnnnnndnddn','1598664932.jpg','0','789','2020-08-29 03:35:32','4','2020-08-29 03:35:32','4');
insert into `product` (`product_id`, `title`, `description`, `image`, `status`, `price`, `created_on`, `created_by`, `updated_on`, `updated_by`) values('7','testing','adbam,bd,mabd,msabd,m','1598666992.png','0','56.80',NULL,NULL,'2020-08-29 04:09:52','4');
