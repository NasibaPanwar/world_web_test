/*
SQLyog Community v13.1.6 (64 bit)
MySQL - 10.4.13-MariaDB : Database - social_login_db
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`social_login_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `social_login_db`;

/*Table structure for table `category` */

DROP TABLE IF EXISTS `category`;

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `image` text NOT NULL,
  `status` smallint(6) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

/*Data for the table `category` */

insert  into `category`(`category_id`,`title`,`description`,`image`,`status`,`created_on`,`created_by`,`updated_on`,`updated_by`) values 
(1,'test','cxzzzzzzzzzzzzzzzzzzzzzzzz','wsndsjdjsa',0,'2020-08-28 22:43:02',1,'2020-08-28 22:43:11',1),
(2,'edfdsf','dsfffffffffffffffffffff','1598658741.jpg',0,NULL,NULL,'2020-08-29 01:52:21',4),
(3,'title','this is an test category','1598658717.png',0,'2020-08-28 23:31:57',4,'2020-08-29 01:51:57',4),
(4,'thsi si an second testing','this is an testing','',1,'2020-08-28 23:32:56',4,'2020-08-28 23:32:56',4),
(6,'fdsfdsfsdfs123','fdsssssssssssssssssssssssss','1598658693.jpg',0,'2020-08-29 01:28:34',4,'2020-08-29 01:51:33',4);

/*Table structure for table `product` */

DROP TABLE IF EXISTS `product`;

CREATE TABLE `product` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `image` text DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `price` varchar(250) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;

/*Data for the table `product` */

insert  into `product`(`product_id`,`title`,`description`,`image`,`status`,`price`,`created_on`,`created_by`,`updated_on`,`updated_by`) values 
(1,'testing','adbam,bd,mabd,msabd,m','1598667644.png',1,'56.80','2020-08-29 05:47:01',NULL,'2020-08-29 04:20:44',4),
(2,'thsi si an second testing','snasmn,msansa,mnamna,mnas,m','1598664334.jpg',1,'750','2020-08-29 03:25:34',4,'2020-08-29 03:25:34',4),
(4,'thsi si an second testing','snasmn,msansa,mnamna,mnas,m','1598664561.jpg',1,'750','2020-08-29 03:29:21',4,'2020-08-29 03:29:21',4),
(5,'thsi si an second testing','snasmn,msansa,mnamna,mnas,m','1598664580.jpg',1,'750','2020-08-29 03:29:40',4,'2020-08-29 03:29:40',4),
(6,'onedzX m','sdmnnnnnnnndnddn','1598664932.jpg',0,'789','2020-08-29 03:35:32',4,'2020-08-29 03:35:32',4),
(7,'testing','adbam,bd,mabd,msabd,m','1598666992.png',0,'56.80',NULL,NULL,'2020-08-29 04:09:52',4);

/*Table structure for table `product_category` */

DROP TABLE IF EXISTS `product_category`;

CREATE TABLE `product_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4;

/*Data for the table `product_category` */

insert  into `product_category`(`id`,`product_id`,`category_id`) values 
(4,5,1),
(5,6,2),
(6,6,3),
(7,6,4),
(12,3,1),
(13,1,6);

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `created_date` datetime DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `user` */

insert  into `user`(`user_id`,`name`,`password`,`email`,`created_date`,`update_date`) values 
(1,'','','Coretesting Bikaner','2016-10-26 13:29:18',NULL),
(2,'','','core','2016-10-26 13:32:25',NULL),
(3,'nasiba','0e54e975bd4250e7465865232bdb08fc','nasiba@gmail.com',NULL,NULL),
(4,'nasiba','e10adc3949ba59abbe56e057f20f883e','one@gmail.com','2020-08-27 22:29:54','2020-08-27 22:29:54');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
